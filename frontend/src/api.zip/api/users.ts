import apiClient from './apiClient';

export const getUsers = async () => {
  const { data } = await apiClient.get('/user');
  return data;
};

export const getUser = async (id: string) => {
  const { data } = await apiClient.get(`/user/${id}`);
  return data;
};

export const createUser = async (userData: { name: string; email: string; password: string; groupId: string }) => {
  const { data } = await apiClient.post('/user', userData);
  return data;
};

export const updateUser = async (id: string, userData: Partial<{ name: string; email: string; password: string; groupId: string }>) => {
  const { data } = await apiClient.put(`/user/${id}`, userData);
  return data;
};

export const deleteUser = async (id: string) => {
  const { data } = await apiClient.delete(`/user/${id}`);
  return data;
};
